﻿CreateClientConVar("zpass_auto_apply", "1", true, true, "Автоматически надевать скин Z-Pass при спавне")

local PANEL = {}

local COLOR_BG = Color(14, 16, 28, 245)
local COLOR_HEADER = Color(10, 12, 22, 255)
local COLOR_CARD = Color(20, 24, 42, 200)
local COLOR_ACCENT = Color(66, 75, 245)
local COLOR_ACCENT_HOVER = Color(85, 95, 255)
local COLOR_TEXT = Color(220, 225, 240)
local COLOR_TEXT_MUTED = Color(140, 145, 170)

local function StyleScrollBar(panel)
    local sbar = panel:GetVBar()
    if not IsValid(sbar) then return end
    sbar:SetHideButtons(true)
    sbar:SetWidth(6)
    sbar.Paint = function() end
    sbar.btnGrip.Paint = function(s, w, h)
        draw.RoundedBox(3, 0, 0, w, h, COLOR_ACCENT)
    end
end

function PANEL:Init()
    local scale = 1.3
    self:SetSize(440 * scale, 580 * scale)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetDraggable(true)
    
    self.Scale = scale
    self.AllowedSkins = {}
    self:SetAlpha(0)
    self:AlphaTo(255, 0.2, 0)
    
    self.btnCloseX = vgui.Create("DButton", self)
    self.btnCloseX:SetPos(self:GetWide() - 32 * scale, 6 * scale)
    self.btnCloseX:SetSize(24 * scale, 20 * scale)
    self.btnCloseX:SetText("✕")
    self.btnCloseX:SetFont("DermaDefaultBold")
    self.btnCloseX:SetTextColor(COLOR_TEXT_MUTED)
    self.btnCloseX.Paint = function() end
    self.btnCloseX.DoClick = function() self:Close() end
    
    local s = self.Scale
    local y = 42 * s
    
    self.lblStatus = vgui.Create("DLabel", self)
    self.lblStatus:SetPos(14 * s, y)
    self.lblStatus:SetSize(self:GetWide() - 28 * s, 30 * s)
    self.lblStatus:SetFont("DermaDefaultBold")
    self.lblStatus:SetContentAlignment(5)
    self.lblStatus:SetTextColor(COLOR_TEXT)
    self:UpdateStatusLabel()
    
    y = y + 38 * s
    self:AddDivider(y)
    y = y + 14 * s
    
    local btnW = self:GetWide() - 28 * s
    local btnH = 40 * s
    
    self.btnSkin = self:AddButton("Выбор модели", y, btnW, btnH, function()
        if not self:CheckPass() then return end
        self:OpenSkinSelector()
    end)
    y = y + btnH + 10 * s

    self.chkAutoApply = vgui.Create("DCheckBoxLabel", self)
    self.chkAutoApply:SetPos(14 * s, y)
    self.chkAutoApply:SetText("Автовыдача скина при спавне")
    self.chkAutoApply:SetFont("DermaDefaultBold")
    self.chkAutoApply:SetTextColor(COLOR_TEXT)
    self.chkAutoApply:SetConVar("zpass_auto_apply")
    self.chkAutoApply:SizeToContents()
    y = y + 25 * s

    self.lblBindHint = vgui.Create("DLabel", self)
    self.lblBindHint:SetPos(14 * s, y)
    self.lblBindHint:SetSize(self:GetWide() - 28 * s, 25 * s)
    self.lblBindHint:SetFont("DermaDefault")
    self.lblBindHint:SetTextColor(COLOR_TEXT_MUTED)
    self.lblBindHint:SetContentAlignment(5)
    self.lblBindHint:SetText("Привязка к клавише: bind [клавиша] zpass_menu")
    self.lblBindHint:SetWrap(true)
    self.lblBindHint:SetAutoStretchVertical(true)
    y = y + 30 * s

    self.btnAdmin = self:AddButton("Настройки Z-PASS (Админ)", y, btnW, btnH, function()
        vgui.Create("ZPass_AdminMenu")
    end)
    self.btnAdmin:SetVisible(false)
    
    y = y + btnH + 10 * s
    self:AddDivider(y)
    y = y + 14 * s
    
    self.lblPassInfo = vgui.Create("DLabel", self)
    self.lblPassInfo:SetPos(14 * s, y)
    self.lblPassInfo:SetSize(self:GetWide() - 28 * s, 160 * s)
    self.lblPassInfo:SetFont("DermaDefault")
    self.lblPassInfo:SetTextColor(COLOR_TEXT_MUTED)
    self.lblPassInfo:SetWrap(true)
    self.lblPassInfo:SetAutoStretchVertical(true)
    self:UpdateInfoText()
    
    self:RequestStatus()
end

function PANEL:CheckPass()
    if not self.PassData or not self.PassData.has then
        self:ShowNotify("У вас нет Z-PASS!")
        return false
    end
    return true
end

function PANEL:OpenSkinSelector()
    if IsValid(ZPass_SkinSelector) then ZPass_SkinSelector:Remove() end
    ZPass_SkinSelector = vgui.Create("ZPass_SkinSelector")
    ZPass_SkinSelector:SetData(self.AllowedSkins, self.PassData and (self.PassData.isAdmin or self.PassData.isSuperAdmin))
end

function PANEL:AddButton(text, y, w, h, callback)
    local btn = vgui.Create("DButton", self)
    btn:SetPos(14 * self.Scale, y)
    btn:SetSize(w, h)
    btn:SetText(text)
    btn:SetFont("DermaDefaultBold")
    btn:SetTextColor(COLOR_TEXT)
    
    btn.Paint = function(s, w, h)
        local hover = s:IsHovered()
        local base = hover and COLOR_ACCENT_HOVER or COLOR_ACCENT
        draw.RoundedBox(8, 0, 0, w, h, base)
    end
    
    btn.DoClick = function()
        surface.PlaySound("ui/buttonclick.wav")
        if callback then callback() end
    end
    return btn
end

function PANEL:AddDivider(y)
    local div = vgui.Create("DPanel", self)
    div:SetPos(14 * self.Scale, y)
    div:SetSize(self:GetWide() - 28 * self.Scale, 1)
    div.Paint = function(s, w, h)
        surface.SetDrawColor(COLOR_ACCENT.r, COLOR_ACCENT.g, COLOR_ACCENT.b, 60)
        surface.DrawRect(0, 0, w, h)
    end
end

function PANEL:UpdateStatusLabel()
    local status = "ЗАГРУЗКА..."
    local color = COLOR_TEXT_MUTED
    
    if self.PassData then
        if self.PassData.isSuperAdmin then
            status = "[СУПЕР АДМИН] Z-PASS +"
            color = Color(255, 215, 0)
        elseif self.PassData.isAdmin then
            status = "[АДМИН] Z-PASS +"
            color = Color(180, 100, 255)
        elseif self.PassData.plus then
            status = "У ВАС ЕСТЬ Z-PASS+"
            color = Color(255, 215, 0)
        elseif self.PassData.has then
            status = "✅ У ВАС ЕСТЬ Z-PASS"
            color = Color(66, 245, 125)
        else
            status = "❌ У ВАС НЕТ Z-PASS"
            color = Color(245, 66, 66)
        end
    end
    
    self.lblStatus:SetText(status)
    self.lblStatus:SetTextColor(color)
end

function PANEL:UpdateInfoText()
    local text = ""
    if self.PassData then
        if self.PassData.isAdmin or self.PassData.isSuperAdmin or self.PassData.plus then
            text = "Что дает Z-PASS+:\n\n• Все привилегии Z-PASS\n• Доступ ко всем скинам администратора\n• Лут не зависит от кармы\n• Повышенный шанс на ценный лут"
        elseif self.PassData.has then
            text = "Что дает Z-PASS:\n\n• Доступ к выбору скинов и бодигрупп\n• Уникальный статус на сервере\n• Меньше проблем с Organizm"
        else
            text = "У вас нет Z-PASS.\n\nПриобретите Z-PASS или Z-PASS+ для доступа к персональной кастомизации!"
        end
    else
        text = "Загрузка информации о Z-PASS..."
    end
    self.lblPassInfo:SetText(text)
end

function PANEL:RequestStatus()
    net.Start("ZPass_RequestStatus")
    net.SendToServer()
end

function PANEL:SetPassData(has, plus, isAdmin, isSuperAdmin, allowedSkins)
    self.PassData = { has = has, plus = plus, isAdmin = isAdmin, isSuperAdmin = isSuperAdmin }
    self.AllowedSkins = allowedSkins or {}
    
    if isAdmin or isSuperAdmin then
        self.btnAdmin:SetVisible(true)
    end
    
    self:UpdateStatusLabel()
    self:UpdateInfoText()
end

function PANEL:ShowNotify(text)
    local notify = vgui.Create("DFrame")
    notify:SetSize(300, 50)
    notify:Center()
    notify:SetTitle("")
    notify:ShowCloseButton(false)
    notify:MakePopup()
    notify:SetAlpha(0)
    notify:AlphaTo(255, 0.2, 0)
    
    local lbl = vgui.Create("DLabel", notify)
    lbl:Dock(FILL)
    lbl:SetText(text)
    lbl:SetFont("DermaDefaultBold")
    lbl:SetContentAlignment(5)
    
    notify.Paint = function(s, w, h)
        draw.RoundedBox(8, 0, 0, w, h, COLOR_HEADER)
        surface.SetDrawColor(COLOR_ACCENT)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    timer.Simple(1.5, function()
        if IsValid(notify) then notify:AlphaTo(0, 0.2, 0, function() notify:Remove() end) end
    end)
end

function PANEL:Paint(w, h)
    draw.RoundedBox(12, 0, 0, w, h, COLOR_BG)
    draw.RoundedBoxEx(12, 0, 0, w, 32 * self.Scale, COLOR_HEADER, true, true, false, false)
    draw.SimpleText("Z-PASS SYSTEM", "DermaDefaultBold", 12 * self.Scale, 7 * self.Scale, COLOR_ACCENT)
    surface.SetDrawColor(COLOR_ACCENT.r, COLOR_ACCENT.g, COLOR_ACCENT.b, 40)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function PANEL:Close()
    self:AlphaTo(0, 0.2, 0, function() self:Remove() end)
end

vgui.Register("ZPass_Menu", PANEL, "DFrame")

local SKIN_PANEL = {}

function SKIN_PANEL:Init()
    local scale = 1.2
    self:SetSize(860 * scale, 590 * scale)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetDraggable(true)
    
    self.Scale = scale
    self.SelectedModel = nil
    self.BodygroupValues = {}
    self.SkinValue = 0
    self.AllowedSkins = {}
    self.IsAdmin = false
    
    local s = self.Scale
    
    self.btnCloseX = vgui.Create("DButton", self)
    self.btnCloseX:SetPos(self:GetWide() - 32 * s, 6 * s)
    self.btnCloseX:SetSize(24 * s, 20 * s)
    self.btnCloseX:SetText("✕")
    self.btnCloseX:SetFont("DermaDefaultBold")
    self.btnCloseX:SetTextColor(COLOR_TEXT_MUTED)
    self.btnCloseX.Paint = function() end
    self.btnCloseX.DoClick = function() self:Close() end
    
    local leftW = 320 * s
    self.pnlLeft = vgui.Create("DPanel", self)
    self.pnlLeft:SetPos(12 * s, 38 * s)
    self.pnlLeft:SetSize(leftW, self:GetTall() - 50 * s)
    self.pnlLeft.Paint = function(p, w, h)
        draw.RoundedBox(8, 0, 0, w, h, COLOR_CARD)
        draw.SimpleText("Предпросмотр", "DermaDefaultBold", 12, 10, COLOR_TEXT_MUTED)
    end
    
    self.ModelPreview = vgui.Create("DModelPanel", self.pnlLeft)
    self.ModelPreview:SetPos(4, 30 * s)
    self.ModelPreview:SetSize(leftW - 8, self.pnlLeft:GetTall() - 75 * s)
    self.ModelPreview:SetFOV(45)
    
    function self.ModelPreview:LayoutEntity(ent)
        if self.Pressing then
            local mx = gui.MouseX()
            self.Angles.y = self.Angles.y + (mx - (self.PrevX or mx)) * 0.6
            self.PrevX = mx
        end
        ent:SetAngles(Angle(0, self.Angles.y, 0))
    end
    self.ModelPreview.Angles = Angle(0, 45, 0)
    self.ModelPreview.OnMousePressed = function(p, btn)
        if btn == MOUSE_LEFT then p.Pressing = true p.PrevX = gui.MouseX() end
    end
    self.ModelPreview.OnMouseReleased = function(p) p.Pressing = false end

    self.btnApply = vgui.Create("DButton", self.pnlLeft)
    self.btnApply:SetPos(8 * s, self.pnlLeft:GetTall() - 36 * s)
    self.btnApply:SetSize(leftW - 16 * s, 28 * s)
    self.btnApply:SetText("Применить скин")
    self.btnApply:SetFont("DermaDefaultBold")
    self.btnApply:SetTextColor(COLOR_TEXT)
    self.btnApply.Paint = function(b, w, h)
        draw.RoundedBox(6, 0, 0, w, h, b:IsHovered() and COLOR_ACCENT_HOVER or COLOR_ACCENT)
    end
    
    self.btnApply.DoClick = function()
        if not self.SelectedModel then return end
        net.Start("ZPass_ApplySkin")
            net.WriteString(self.SelectedModel)
            net.WriteUInt(self.SkinValue, 8)
            net.WriteTable(self.BodygroupValues)
        net.SendToServer()
    end

    local rightX = leftW + 20 * s
    local rightW = self:GetWide() - rightX - 12 * s
    
    self.pnlRight = vgui.Create("DPanel", self)
    self.pnlRight:SetPos(rightX, 38 * s)
    self.pnlRight:SetSize(rightW, self:GetTall() - 50 * s)
    self.pnlRight.Paint = function(p, w, h)
        draw.RoundedBox(8, 0, 0, w, h, COLOR_CARD)
        draw.SimpleText("Доступные модели", "DermaDefaultBold", 12, 10, COLOR_TEXT_MUTED)
    end

    self.txtSearch = vgui.Create("DTextEntry", self.pnlRight)
    self.txtSearch:SetPos(8 * s, 32 * s)
    self.txtSearch:SetSize(rightW - 16 * s, 24 * s)
    self.txtSearch:SetPlaceholderText("Поиск...")
    self.txtSearch:SetTextColor(COLOR_TEXT)
    self.txtSearch:SetDrawLanguageID(false)
    self.txtSearch.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(10, 12, 22, 200))
        s:DrawTextEntryText(COLOR_TEXT, COLOR_ACCENT, COLOR_TEXT)
    end
    self.txtSearch.OnValueChange = function() self:FilterSkins() end

    self.pnlScroll = vgui.Create("DScrollPanel", self.pnlRight)
    self.pnlScroll:SetPos(8 * s, 62 * s)
    self.pnlScroll:SetSize(rightW - 16 * s, 230 * s)
    StyleScrollBar(self.pnlScroll)

    self.pnlIcons = self.pnlScroll:Add("DIconLayout")
    self.pnlIcons:SetSpaceX(6 * s)
    self.pnlIcons:SetSpaceY(6 * s)
    self.pnlIcons:Dock(TOP)

    self.pnlCustom = vgui.Create("DPanel", self.pnlRight)
    self.pnlCustom:SetPos(8 * s, 298 * s)
    self.pnlCustom:SetSize(rightW - 16 * s, self.pnlRight:GetTall() - 306 * s)
    self.pnlCustom.Paint = function(p, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(10, 12, 22, 180))
        draw.SimpleText("Редактор бодигрупп", "DermaDefaultBold", 10, 6, COLOR_ACCENT)
        surface.SetDrawColor(COLOR_ACCENT.r, COLOR_ACCENT.g, COLOR_ACCENT.b, 30)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    self.pnlBodyScroll = vgui.Create("DScrollPanel", self.pnlCustom)
    self.pnlBodyScroll:Dock(FILL)
    self.pnlBodyScroll:DockMargin(4, 26, 4, 4)
    StyleScrollBar(self.pnlBodyScroll)
end

function SKIN_PANEL:SetData(allowedSkins, isAdmin)
    self.AllowedSkins = allowedSkins or {}
    self.IsAdmin = isAdmin
    self:LoadSkins()
    self:SelectModel(LocalPlayer():GetModel())
end

function SKIN_PANEL:LoadSkins()
    local allModels = player_manager.AllValidModels()
    local skinList = {}
    for name, model in pairs(allModels) do
        if self.IsAdmin or self.AllowedSkins[model] then
            table.insert(skinList, { name = name, model = model })
        end
    end
    table.sort(skinList, function(a, b) return a.name < b.name end)
    
    self.AllSkins = skinList
    self:FilterSkins()
end

function SKIN_PANEL:FilterSkins()
    self.pnlIcons:Clear()
    local filter = self.txtSearch:GetValue():lower()
    local iconSize = 58 * self.Scale

    for _, skin in ipairs(self.AllSkins or {}) do
        if filter == "" or string.find(skin.name:lower(), filter, 1, true) or string.find(skin.model:lower(), filter, 1, true) then
            local icon = vgui.Create("SpawnIcon", self.pnlIcons)
            icon:SetSize(iconSize, iconSize)
            icon:SetModel(skin.model)
            icon:SetTooltip(skin.name)
            
            icon.DoClick = function()
                self:SelectModel(skin.model)
            end
        end
    end
end

function SKIN_PANEL:SelectModel(mdl)
    if not mdl or mdl == "" then return end
    self.SelectedModel = mdl
    self.BodygroupValues = {}
    self.SkinValue = 0

    self.ModelPreview:SetModel(mdl)
    local ent = self.ModelPreview.Entity
    if IsValid(ent) then
        local mn, mx = ent:GetRenderBounds()
        local size = math.max(math.abs(mn.x) + math.abs(mx.x), math.abs(mn.y) + math.abs(mx.y), math.abs(mn.z) + math.abs(mn.z))
        self.ModelPreview:SetCamPos(Vector(size, size, size * 0.5))
        self.ModelPreview:SetLookAt((mn + mx) * 0.5)
    end

    self:BuildCustomizationOptions()
end

function SKIN_PANEL:BuildCustomizationOptions()
    self.pnlBodyScroll:Clear()
    local ent = self.ModelPreview.Entity
    if not IsValid(ent) then return end

    local numSkins = ent:SkinCount()
    if numSkins > 1 then
        self:CreateNumControl("Skin / Текстура", 0, numSkins - 1, 0, function(val)
            self.SkinValue = val
            if IsValid(ent) then ent:SetSkin(val) end
        end)
    end

    for _, bg in ipairs(ent:GetBodyGroups() or {}) do
        if bg.num > 1 then
            self:CreateNumControl(bg.name, 0, bg.num - 1, 0, function(val)
                self.BodygroupValues[bg.id] = val
                if IsValid(ent) then ent:SetBodygroup(bg.id, val) end
            end)
        end
    end
end

function SKIN_PANEL:CreateNumControl(title, minVal, maxVal, defaultVal, onChange)
    local row = vgui.Create("DPanel", self.pnlBodyScroll)
    row:Dock(TOP)
    row:DockMargin(0, 2, 0, 6)
    row:SetTall(28)
    row.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(16, 20, 36, 180))
    end

    local lbl = vgui.Create("DLabel", row)
    lbl:Dock(LEFT)
    lbl:SetWidth(110)
    lbl:SetText("  " .. title)
    lbl:SetFont("DermaDefaultBold")
    lbl:SetTextColor(COLOR_TEXT)

    local slider = vgui.Create("DSlider", row)
    slider:Dock(FILL)
    slider:SetLockY(0.5)
    slider:SetSlideX(defaultVal / math.max(1, maxVal))

    local lblVal = vgui.Create("DLabel", row)
    lblVal:Dock(RIGHT)
    lblVal:SetWidth(35)
    lblVal:SetText(tostring(defaultVal))
    lblVal:SetContentAlignment(5)
    lblVal:SetFont("DermaDefaultBold")
    lblVal:SetTextColor(COLOR_ACCENT)

    slider.Paint = function(s, w, h)
        local cy = h / 2
        draw.RoundedBox(2, 8, cy - 2, w - 16, 4, Color(30, 35, 60))
        draw.RoundedBox(2, 8, cy - 2, (w - 16) * s:GetSlideX(), 4, COLOR_ACCENT)
    end

    slider.Knob.Paint = function(s, w, h)
        draw.RoundedBox(6, 0, 2, 12, 12, COLOR_ACCENT)
    end

    slider.OnValueChanged = function(s, x, y)
        local val = math.Round(x * maxVal)
        lblVal:SetText(tostring(val))
        onChange(val)
    end
end

function SKIN_PANEL:Paint(w, h)
    draw.RoundedBox(12, 0, 0, w, h, COLOR_BG)
    draw.RoundedBoxEx(12, 0, 0, w, 32 * self.Scale, COLOR_HEADER, true, true, false, false)
    draw.SimpleText("Селектор моделей игрока", "DermaDefaultBold", 12 * self.Scale, 7 * self.Scale, COLOR_ACCENT)
    surface.SetDrawColor(COLOR_ACCENT.r, COLOR_ACCENT.g, COLOR_ACCENT.b, 40)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function SKIN_PANEL:Close()
    self:AlphaTo(0, 0.2, 0, function() self:Remove() end)
end

vgui.Register("ZPass_SkinSelector", SKIN_PANEL, "DFrame")

local ADMIN_PANEL = {}

function ADMIN_PANEL:Init()
    self:SetSize(720, 520)
    self:Center()
    self:SetTitle("Настройка системы Z-PASS")
    self:MakePopup()
    
    self.Sheet = vgui.Create("DPropertySheet", self)
    self.Sheet:Dock(FILL)
    
    self.pnlUsers = vgui.Create("DPanel", self.Sheet)
    self:BuildUsersTab(self.pnlUsers)
    self.Sheet:AddSheet("Управление пропусками", self.pnlUsers, "icon16/user_edit.png")
    
    self.pnlSkins = vgui.Create("DPanel", self.Sheet)
    self:BuildSkinsTab(self.pnlSkins)
    self.Sheet:AddSheet("Разрешенные скины", self.pnlSkins, "icon16/photos.png")

    net.Start("ZPass_Admin_OpenMenu")
    net.SendToServer()
end

function ADMIN_PANEL:BuildUsersTab(pnl)
    pnl.Paint = function(s, w, h) draw.RoundedBox(0, 0, 0, w, h, COLOR_BG) end

    local lbl = vgui.Create("DLabel", pnl)
    lbl:SetPos(10, 10)
    lbl:SetText("Укажите ник или SteamID игрока:")
    lbl:SetTextColor(COLOR_TEXT)
    lbl:SizeToContents()
    
    local txtTarget = vgui.Create("DTextEntry", pnl)
    txtTarget:SetPos(10, 30)
    txtTarget:SetSize(300, 25)
    
    local btnAdd = vgui.Create("DButton", pnl)
    btnAdd:SetPos(10, 65)
    btnAdd:SetSize(140, 30)
    btnAdd:SetText("Выдать Z-PASS")
    btnAdd:SetTextColor(COLOR_TEXT)
    btnAdd.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, COLOR_ACCENT) end
    btnAdd.DoClick = function()
        net.Start("ZPass_Admin_ManagePass")
            net.WriteString(txtTarget:GetValue())
            net.WriteString("add")
        net.SendToServer()
    end
    
    local btnAddPlus = vgui.Create("DButton", pnl)
    btnAddPlus:SetPos(160, 65)
    btnAddPlus:SetSize(140, 30)
    btnAddPlus:SetText("Выдать Z-PASS+")
    btnAddPlus:SetTextColor(COLOR_TEXT)
    btnAddPlus.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, Color(255, 180, 0)) end
    btnAddPlus.DoClick = function()
        net.Start("ZPass_Admin_ManagePass")
            net.WriteString(txtTarget:GetValue())
            net.WriteString("addplus")
        net.SendToServer()
    end
    
    local btnRemove = vgui.Create("DButton", pnl)
    btnRemove:SetPos(310, 65)
    btnRemove:SetSize(140, 30)
    btnRemove:SetText("Забрать Z-PASS")
    btnRemove:SetTextColor(COLOR_TEXT)
    btnRemove.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, Color(200, 50, 50)) end
    btnRemove.DoClick = function()
        net.Start("ZPass_Admin_ManagePass")
            net.WriteString(txtTarget:GetValue())
            net.WriteString("remove")
        net.SendToServer()
    end

    local lblList = vgui.Create("DLabel", pnl)
    lblList:SetPos(10, 110)
    lblList:SetText("Список владельцев Z-PASS (из data/zpass/players.json):")
    lblList:SetTextColor(COLOR_TEXT_MUTED)
    lblList:SizeToContents()

    self.ListView = vgui.Create("DListView", pnl)
    self.ListView:SetPos(10, 130)
    self.ListView:SetSize(680, 310)
    self.ListView:AddColumn("Ник")
    self.ListView:AddColumn("SteamID")
    self.ListView:AddColumn("Тип")
    self.ListView:AddColumn("Кем выдан (Ник)")
    self.ListView:AddColumn("Кем выдан (SteamID)")
end

function ADMIN_PANEL:BuildSkinsTab(pnl)
    pnl.Paint = function(s, w, h) draw.RoundedBox(0, 0, 0, w, h, COLOR_BG) end

    self.pnlSkinScroll = vgui.Create("DScrollPanel", pnl)
    self.pnlSkinScroll:Dock(FILL)
    StyleScrollBar(self.pnlSkinScroll)
    
    self.SkinList = vgui.Create("DIconLayout", self.pnlSkinScroll)
    self.SkinList:Dock(FILL)
    self.SkinList:SetSpaceX(5)
    self.SkinList:SetSpaceY(5)
end

function ADMIN_PANEL:PopulateSkins(allowedSkins)
    if not IsValid(self.SkinList) then return end
    self.SkinList:Clear()
    
    local allModels = player_manager.AllValidModels()
    for name, model in pairs(allModels) do
        local container = vgui.Create("DPanel", self.SkinList)
        container:SetSize(90, 110)
        container.Paint = function(s, w, h) draw.RoundedBox(4, 0, 0, w, h, COLOR_CARD) end
        
        local icon = vgui.Create("SpawnIcon", container)
        icon:SetSize(80, 80)
        icon:SetPos(5, 5)
        icon:SetModel(model)
        
        local chk = vgui.Create("DCheckBoxLabel", container)
        chk:SetPos(5, 88)
        chk:SetText("Виден")
        chk:SetTextColor(COLOR_TEXT)
        chk:SetChecked(allowedSkins[model] or false)
        chk.OnChange = function(s, val)
            net.Start("ZPass_Admin_ToggleSkin")
                net.WriteString(model)
                net.WriteBool(val)
            net.SendToServer()
        end
    end
end

function ADMIN_PANEL:PopulateUsers(usersData)
    if not IsValid(self.ListView) then return end
    self.ListView:Clear()
    for steamid, data in pairs(usersData or {}) do
        self.ListView:AddLine(data.nick or "N/A", steamid, data.type or "Z-PASS", data.issuer_nick or "CONSOLE", data.issuer_steamid or "SERVER")
    end
end

vgui.Register("ZPass_AdminMenu", ADMIN_PANEL, "DFrame")

net.Receive("ZPass_SendStatus", function()
    local has = net.ReadBool()
    local plus = net.ReadBool()
    local isAdmin = net.ReadBool()
    local isSuperAdmin = net.ReadBool()
    local allowedSkins = net.ReadTable()
    
    if IsValid(ZPass_MenuPanel) then
        ZPass_MenuPanel:SetPassData(has, plus, isAdmin, isSuperAdmin, allowedSkins)
    end
end)

net.Receive("ZPass_Admin_SendMenuData", function()
    local allowedSkins = net.ReadTable()
    local usersData = net.ReadTable()
    
    for _, v in pairs(vgui.GetWorldPanel():GetChildren()) do
        if v:GetName() == "ZPass_AdminMenu" then
            v:PopulateSkins(allowedSkins)
            v:PopulateUsers(usersData)
        end
    end
end)

concommand.Add("zpass_menu", function()
    if IsValid(ZPass_MenuPanel) then
        ZPass_MenuPanel:Close()
        return
    end
    
    ZPass_MenuPanel = vgui.Create("ZPass_Menu")
    surface.PlaySound("ui/buttonclick.wav")
end)

hook.Add("InitPostEntity", "ZPass_RequestOnStart", function()
    timer.Simple(1, function()
        net.Start("ZPass_RequestStatus")
        net.SendToServer()
    end)
end)
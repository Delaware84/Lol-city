﻿local PANEL = {}

function PANEL:Init()
    local scale = 1.5
    self:SetSize(420 * scale, 380 * scale)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetDraggable(true)
    self:SetSizable(false)
    
    self.Scale = scale
    self:AlphaTo(255, 0.3, 0)
    
    -- Крестик
    self.btnCloseX = vgui.Create("DButton", self)
    self.btnCloseX:SetPos(self:GetWide() - 32 * scale, 4 * scale)
    self.btnCloseX:SetSize(28 * scale, 20 * scale)
    self.btnCloseX:SetText("✕")
    self.btnCloseX:SetFont("DermaDefaultBold")
    self.btnCloseX:SetTextColor(Color(200, 200, 200))
    self.btnCloseX.Paint = function() end
    self.btnCloseX.DoClick = function() self:Close() end
    self.btnCloseX.OnCursorEntered = function(s) s:SetTextColor(Color(255, 80, 80)) end
    self.btnCloseX.OnCursorExited = function(s) s:SetTextColor(Color(200, 200, 200)) end
    
    local s = 15 * scale
    local h = 28 * scale
    local w = 390 * scale
    
    -- === ВОПРОС ===
    local lblQuestion = vgui.Create("DLabel", self)
    lblQuestion:SetPos(s, 35 * scale)
    lblQuestion:SetText("Вопрос голосования")
    lblQuestion:SetFont("DermaDefaultBold")
    lblQuestion:SetTextColor(Color(66, 75, 245))
    lblQuestion:SizeToContents()
    
    self.txtQuestion = vgui.Create("DTextEntry", self)
    self.txtQuestion:SetPos(s, 58 * scale)
    self.txtQuestion:SetSize(w, h)
    self.txtQuestion:SetFont("DermaDefault")
    self.txtQuestion:SetPlaceholderText("Например: Какой режим запустить?")
    self.txtQuestion:SetDrawBackground(false)
    self.txtQuestion.Paint = function(s, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(20, 20, 30))
        draw.RoundedBox(6, 1, 1, w-2, h-2, Color(15, 15, 25))
        if s:IsEditing() then
            surface.SetDrawColor(66, 75, 245, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        s:DrawTextEntryText(Color(200, 200, 210), Color(66, 75, 245), Color(255, 255, 255))
    end
    
    -- === ВАРИАНТЫ ===
    local lblOptions = vgui.Create("DLabel", self)
    lblOptions:SetPos(s, 98 * scale)
    lblOptions:SetText("Варианты ответа (минимум 2)")
    lblOptions:SetFont("DermaDefaultBold")
    lblOptions:SetTextColor(Color(120, 130, 200))
    lblOptions:SizeToContents()
    
    self.optionInputs = {}
    
    for i = 1, 5 do
        local txt = vgui.Create("DTextEntry", self)
        txt:SetPos(s, 120 * scale + (i-1) * (h + 8 * scale))
        txt:SetSize(w, h)
        txt:SetFont("DermaDefault")
        txt:SetPlaceholderText("Вариант " .. i .. (i <= 2 and " *" or " (опционально)"))
        txt:SetDrawBackground(false)
        txt.Paint = function(s, w, h)
            draw.RoundedBox(6, 0, 0, w, h, Color(20, 20, 30))
            draw.RoundedBox(6, 1, 1, w-2, h-2, Color(15, 15, 25))
            if s:IsEditing() then
                surface.SetDrawColor(66, 75, 245, 100)
                surface.DrawOutlinedRect(0, 0, w, h, 2)
            end
            -- Синяя полоска слева
            surface.SetDrawColor(66, 75, 245)
            surface.DrawRect(0, 4, 3, h - 8)
            s:DrawTextEntryText(Color(200, 200, 210), Color(66, 75, 245), Color(255, 255, 255))
        end
        self.optionInputs[i] = txt
    end
    
    -- === ВРЕМЯ ===
    local lblTime = vgui.Create("DLabel", self)
    lblTime:SetPos(s, 290 * scale)
    lblTime:SetText("Время:")
    lblTime:SetFont("DermaDefaultBold")
    lblTime:SetTextColor(Color(120, 130, 200))
    lblTime:SizeToContents()
    
    self.numTime = vgui.Create("DNumberWang", self)
    self.numTime:SetPos(s + 70 * scale, 288 * scale)
    self.numTime:SetSize(70 * scale, 26 * scale)
    self.numTime:SetFont("DermaDefault")
    self.numTime:SetMin(10)
    self.numTime:SetMax(300)
    self.numTime:SetValue(60)
    self.numTime:SetDrawBackground(false)
    self.numTime.Paint = function(s, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(20, 20, 30))
        draw.RoundedBox(6, 1, 1, w-2, h-2, Color(15, 15, 25))
        if s:IsEditing() then
            surface.SetDrawColor(66, 75, 245, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        s:DrawTextEntryText(Color(200, 200, 210), Color(66, 75, 245), Color(255, 255, 255))
    end
    
    local lblSec = vgui.Create("DLabel", self)
    lblSec:SetPos(s + 145 * scale, 292 * scale)
    lblSec:SetText("секунд")
    lblSec:SetFont("DermaDefault")
    lblSec:SetTextColor(Color(100, 100, 120))
    lblSec:SizeToContents()
    
    -- === КНОПКА СТАРТА ===
    self.btnStart = vgui.Create("DButton", self)
    self.btnStart:SetPos(s, 330 * scale)
    self.btnStart:SetSize(w, 38 * scale)
    self.btnStart:SetText("Начать голосование")
    self.btnStart:SetFont("DermaDefaultBold")
    self.btnStart:SetTextColor(Color(255, 255, 255))
    
    self.btnStart.Paint = function(s, w, h)
        local hover = s:IsHovered()
        local press = s:IsDown()
        local base = hover and Color(80, 90, 255) or Color(66, 75, 245)
        if press then base = Color(50, 58, 200) end
        
        draw.RoundedBox(8, 0, 0, w, h, base)
        -- Градиент сверху
        surface.SetDrawColor(255, 255, 255, 15)
        surface.DrawRect(4, 2, w - 8, h / 2 - 2)
        
        if hover then
            surface.SetDrawColor(100, 110, 255, 40)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
    end
    
    self.btnStart.DoClick = function()
        surface.PlaySound("buttons/button14.wav")
        self:StartVote()
    end
    
    self.btnStart.OnCursorEntered = function() surface.PlaySound("ui/buttonrollover.wav") end
end

function PANEL:Paint(w, h)
    draw.RoundedBox(12, 0, 0, w, h, Color(14, 16, 45, 250))
    draw.RoundedBoxEx(12, 0, 0, w, 28 * self.Scale, Color(12, 12, 25), true, true, false, false)
    draw.SimpleText("Создание голосования", "DermaDefaultBold", 12 * self.Scale, 6 * self.Scale, Color(66, 75, 245))
    surface.SetDrawColor(40, 40, 70)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function PANEL:Close()
    self:AlphaTo(0, 0.2, 0, function() self:Remove() end)
end

function PANEL:StartVote()
    local question = self.txtQuestion:GetValue():Trim()
    if question == "" then
        surface.PlaySound("buttons/button10.wav")
        local x, y = self:GetPos()
        self:SetPos(x + 5, y)
        timer.Simple(0.05, function() if IsValid(self) then self:SetPos(x - 5, y) end end)
        timer.Simple(0.1, function() if IsValid(self) then self:SetPos(x + 3, y) end end)
        timer.Simple(0.15, function() if IsValid(self) then self:SetPos(x, y) end end)
        return
    end
    
    local options = {}
    for i = 1, 5 do
        local val = self.optionInputs[i]:GetValue():Trim()
        if val ~= "" then
            table.insert(options, val)
        end
    end
    
    if #options < 2 then
        surface.PlaySound("buttons/button10.wav")
        return
    end
    
    net.Start("ZVote_CreateVote")
    net.WriteString(question)
    net.WriteTable(options)
    net.WriteInt(self.numTime:GetValue(), 16)
    net.SendToServer()
    
    self:Close()
end

vgui.Register("ZVote_Creator", PANEL, "DFrame")

net.Receive("ZVote_OpenCreator", function()
    if IsValid(ZVote_CreatorPanel) then ZVote_CreatorPanel:Remove() end
    ZVote_CreatorPanel = vgui.Create("ZVote_Creator")
    surface.PlaySound("ui/buttonclick.wav")
end)
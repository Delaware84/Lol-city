﻿local PANEL = {}

function PANEL:Init()
    local scale = 1.5
    self:SetSize(460 * scale, 400 * scale)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetDraggable(true)
    
    self.Results = {}
    self.TotalVotes = 0
    self.MyVote = nil
    self.Scale = scale
    self.BarAnims = {}
    
    self:InvalidateLayout()
    self:AlphaTo(255, 0.3, 0)
    
    -- Крестик
    self.btnCloseX = vgui.Create("DButton", self)
    self.btnCloseX:SetPos(self:GetWide() - 32 * scale, 4 * scale)
    self.btnCloseX:SetSize(28 * scale, 20 * scale)
    self.btnCloseX:SetText("✕")
    self.btnCloseX:SetFont("DermaDefaultBold")
    self.btnCloseX:SetTextColor(Color(200, 200, 200))
    self.btnCloseX.Paint = function() end
    self.btnCloseX.DoClick = function() self:Minimize() end
    self.btnCloseX.OnCursorEntered = function(s) s:SetTextColor(Color(255, 80, 80)) end
    self.btnCloseX.OnCursorExited = function(s) s:SetTextColor(Color(200, 200, 200)) end
end

function PANEL:SetVoteData(question, options, duration)
    local s = self.Scale
    self.Question = question
    self.Options = options
    self.Duration = duration
    self.StartTime = CurTime()
    self.EndTime = CurTime() + duration
    
    -- === ВОПРОС ===
    self.pnlQuestionBg = vgui.Create("DPanel", self)
    self.pnlQuestionBg:SetPos(12 * s, 32 * s)
    self.pnlQuestionBg:SetSize(436 * s, 55 * s)
    self.pnlQuestionBg.Paint = function(p, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(20, 20, 35))
        surface.SetDrawColor(66, 75, 245, 80)
        surface.DrawRect(8, 2, w - 16, 2)
    end
    
    self.lblQuestion = vgui.Create("DLabel", self.pnlQuestionBg)
    self.lblQuestion:Dock(FILL)
    self.lblQuestion:DockMargin(10 * s, 8 * s, 10 * s, 8 * s)
    self.lblQuestion:SetText(question)
    self.lblQuestion:SetFont("DermaDefaultBold")
    self.lblQuestion:SetContentAlignment(5)
    self.lblQuestion:SetWrap(true)
    self.lblQuestion:SetAutoStretchVertical(true)
    self.lblQuestion:SetTextColor(Color(220, 220, 220))
    
    -- === ТАЙМЕР ===
    self.lblTimer = vgui.Create("DLabel", self)
    self.lblTimer:SetPos(12 * s, 92 * s)
    self.lblTimer:SetSize(436 * s, 26 * s)
    self.lblTimer:SetFont("DermaDefaultBold")
    self.lblTimer:SetContentAlignment(5)
    self.lblTimer:SetTextColor(Color(120, 130, 200))
    
    -- === КНОПКИ ВАРИАНТОВ ===
    self.optionButtons = {}
    
    for i, opt in ipairs(options) do
        local yPos = 125 * s + (i-1) * (58 * s)
        
        local btn = vgui.Create("DButton", self)
        btn:SetPos(12 * s, yPos)
        btn:SetSize(436 * s, 48 * s)
        btn:SetText("")
        btn.OptionIndex = i
        
        btn.Paint = function(s, w, h)
            local hover = s:IsHovered()
            local voted = self.MyVote == i
            local base = voted and Color(40, 45, 120) or (hover and Color(35, 38, 70) or Color(25, 25, 45))
            
            draw.RoundedBox(8, 0, 0, w, h, base)
            
            -- Прогресс-бар
            local res = self.Results[i] or { percent = 0, count = 0 }
            local targetW = (w - 6) * (res.percent / 100)
            self.BarAnims[i] = self.BarAnims[i] or 0
            self.BarAnims[i] = Lerp(FrameTime() * 8, self.BarAnims[i], targetW)
            
            if self.BarAnims[i] > 1 then
                local barAlpha = voted and 100 or 60
                draw.RoundedBox(6, 3, 3, self.BarAnims[i], h - 6, Color(66, 75, 245, barAlpha))
            end
            
            -- Рамка
            if hover or voted then
                surface.SetDrawColor(66, 75, 245, voted and 120 or 50)
                surface.DrawOutlinedRect(0, 0, w, h, voted and 2 or 1)
            end
            
            -- Текст
            draw.SimpleText(opt, "DermaDefaultBold", 14, h/2, Color(220, 220, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            
            if res.percent > 0 then
                draw.SimpleText(res.percent .. "% (" .. res.count .. ")", "DermaDefaultBold", w - 12, h/2, Color(120, 130, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end
        
        btn.DoClick = function()
            if self.MyVote then return end
            self:Vote(i)
        end
        
        btn.OnCursorEntered = function() if not self.MyVote then surface.PlaySound("ui/buttonrollover.wav") end end
        
        self.optionButtons[i] = btn
    end
    
    self:SetTall(125 * s + #options * (58 * s) + 60 * s)
    
    -- === КНОПКА СВЕРНУТЬ ===
    self.btnMinimize = vgui.Create("DButton", self)
    self.btnMinimize:SetPos(12 * s, self:GetTall() - 48 * s)
    self.btnMinimize:SetSize(436 * s, 38 * s)
    self.btnMinimize:SetText("Свернуть (голосование продолжается)")
    self.btnMinimize:SetFont("DermaDefault")
    self.btnMinimize:SetTextColor(Color(150, 150, 150))
    
    self.btnMinimize.Paint = function(s, w, h)
        local hover = s:IsHovered()
        draw.RoundedBox(8, 0, 0, w, h, hover and Color(35, 35, 55) or Color(25, 25, 40))
        surface.SetDrawColor(66, 75, 245, hover and 60 or 30)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    self.btnMinimize.DoClick = function()
        self:Minimize()
    end
end

function PANEL:Vote(option)
    if self.MyVote then return end
    self.MyVote = option
    
    net.Start("ZVote_CastVote")
    net.WriteInt(option, 8)
    net.SendToServer()
    
    surface.PlaySound("buttons/button9.wav")
end

function PANEL:UpdateResults(results, total)
    self.Results = results
    self.TotalVotes = total
end

function PANEL:Minimize()
    self:AlphaTo(0, 0.2, 0, function()
        self:SetVisible(false)
        ZVote:ShowMiniPanel()
    end)
end

function PANEL:Think()
    if self.EndTime then
        local remaining = math.max(0, self.EndTime - CurTime())
        local mins = math.floor(remaining / 60)
        local secs = math.floor(remaining % 60)
        local timeStr = string.format("%02d:%02d", mins, secs)
        
        local timeColor = remaining <= 10 and Color(245, 66, 66) or Color(120, 130, 200)
        if remaining <= 10 and math.sin(CurTime() * 6) > 0 then
            timeColor = Color(255, 50, 50)
        end
        
        self.lblTimer:SetText("Осталось: " .. timeStr .. "  |  Всего голосов: " .. self.TotalVotes)
        self.lblTimer:SetTextColor(timeColor)
        
        if remaining <= 0 then
            self:Remove()
        end
    end
end

function PANEL:Paint(w, h)
    draw.RoundedBox(12, 0, 0, w, h, Color(14, 16, 45, 250))
    draw.RoundedBoxEx(12, 0, 0, w, 28 * self.Scale, Color(12, 12, 25), true, true, false, false)
    draw.SimpleText("Голосование", "DermaDefaultBold", 12 * self.Scale, 6 * self.Scale, Color(66, 75, 245))
    surface.SetDrawColor(40, 40, 70)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

vgui.Register("ZVote_Voter", PANEL, "DFrame")

-- ==================== МИНИ-ПАНЕЛЬ ====================

local MINI = {}

function MINI:Init()
    self:SetSize(220, 140)
    self:SetPos(ScrW() - 230, 15)
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:SetDraggable(true)
    self:AlphaTo(255, 0.3, 0)
    
    self.Results = {}
    self.Question = "..."
    self.BarAnims = {}
    self.Pulse = 0
end

function MINI:SetData(question, options)
    self.Question = question
    self.Options = options
    self:SetTall(40 + #options * 26 + 22)
end

function MINI:UpdateResults(results, total)
    self.Results = results
    self.TotalVotes = total
end

function MINI:Paint(w, h)
    draw.RoundedBox(8, 2, 2, w, h, Color(0, 0, 0, 100))
    draw.RoundedBox(8, 0, 0, w, h, Color(14, 16, 45, 245))
    
    draw.RoundedBoxEx(8, 0, 0, w, 26, Color(12, 12, 25), true, true, false, false)
    local qText = string.len(self.Question) > 22 and string.sub(self.Question, 1, 22) .. "..." or self.Question
    draw.SimpleText(qText, "DermaDefaultBold", 8, 4, Color(66, 75, 245))
    
    self.Pulse = math.max(0, self.Pulse - FrameTime() * 3)
    
    for i, opt in ipairs(self.Options or {}) do
        local y = 28 + (i-1) * 26
        local res = self.Results[i] or { percent = 0, count = 0 }
        
        draw.RoundedBox(4, 6, y, w - 12, 20, Color(20, 20, 35))
        
        self.BarAnims[i] = self.BarAnims[i] or 0
        self.BarAnims[i] = Lerp(FrameTime() * 6, self.BarAnims[i], res.percent)
        
        local barW = (w - 14) * (self.BarAnims[i] / 100)
        if barW > 1 then
            draw.RoundedBox(4, 7, y + 1, barW, 18, Color(66, 75, 245, 80))
        end
        
        local label = string.len(opt) > 16 and string.sub(opt, 1, 16) .. "..." or opt
        draw.SimpleText(label, "DermaDefault", 10, y + 10, Color(200, 200, 210), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(res.percent .. "%", "DermaDefault", w - 8, y + 10, Color(120, 130, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    
    draw.SimpleText("Всего: " .. (self.TotalVotes or 0), "DermaDefault", 8, h - 4, Color(100, 100, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
    draw.SimpleText("Клик — развернуть", "DefaultSmall", w - 6, h - 4, Color(80, 80, 100), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
    
    surface.SetDrawColor(40, 40, 70)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

function MINI:OnMousePressed()
    surface.PlaySound("ui/buttonclick.wav")
    ZVote:OpenVoterFromMini()
    self:Remove()
end

function MINI:OnCursorEntered()
    surface.PlaySound("ui/buttonrollover.wav")
end

vgui.Register("ZVote_MiniPanel", MINI, "DFrame")

-- ==================== ИТОГОВОЕ ОКНО ====================

local RESULT = {}

function RESULT:Init()
    self:SetSize(400, 280)
    self:Center()
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:MakePopup()
    self:SetDraggable(true)
    self:AlphaTo(255, 0.4, 0)
    
    self.btnClose = vgui.Create("DButton", self)
    self.btnClose:SetPos(self:GetWide()/2 - 60, self:GetTall() - 45)
    self.btnClose:SetSize(120, 32)
    self.btnClose:SetText("Закрыть")
    self.btnClose:SetFont("DermaDefaultBold")
    self.btnClose:SetTextColor(Color(255, 255, 255))
    self.btnClose.Paint = function(s, w, h)
        local hover = s:IsHovered()
        draw.RoundedBox(8, 0, 0, w, h, hover and Color(50, 58, 180) or Color(35, 42, 140))
    end
    self.btnClose.DoClick = function() self:Remove() end
end

function RESULT:SetData(question, results, winnerIndex, options)
    self.Question = question
    self.Results = results
    self.WinnerIndex = winnerIndex
    self.Options = options
    self.BarAnims = {}
    
    self:SetTall(120 + #options * 40)
    self.btnClose:SetPos(self:GetWide()/2 - 60, self:GetTall() - 45)
end

function RESULT:Paint(w, h)
    draw.RoundedBox(12, 0, 0, w, h, Color(14, 16, 45, 250))
    draw.RoundedBoxEx(12, 0, 0, w, 30, Color(12, 12, 25), true, true, false, false)
    draw.SimpleText("Результаты голосования", "DermaDefaultBold", 12, 6, Color(66, 75, 245))
    
    draw.SimpleText(self.Question or "", "DermaDefaultBold", w/2, 45, Color(200, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    if self.WinnerIndex and self.Options and self.Options[self.WinnerIndex] then
        local winnerText = "Победитель: " .. self.Options[self.WinnerIndex]
        draw.SimpleText(winnerText, "DermaDefaultBold", w/2, 68, Color(66, 75, 245), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    for i, opt in ipairs(self.Options or {}) do
        local y = 90 + (i-1) * 38
        local res = self.Results[i] or { percent = 0, count = 0 }
        
        self.BarAnims[i] = self.BarAnims[i] or 0
        self.BarAnims[i] = math.min(self.BarAnims[i] + FrameTime() * 60, res.percent)
        
        draw.RoundedBox(4, 20, y, w - 40, 22, Color(20, 20, 35))
        
        local barW = (w - 44) * (self.BarAnims[i] / 100)
        local isWinner = i == self.WinnerIndex
        
        if barW > 1 then
            local alpha = isWinner and 120 or 70
            draw.RoundedBox(4, 21, y + 1, barW, 20, Color(66, 75, 245, alpha))
        end
        
        if isWinner then
            surface.SetDrawColor(66, 75, 245, 100)
            surface.DrawOutlinedRect(20, y, w - 40, 22, 2)
        end
        
        draw.SimpleText(opt, "DermaDefault", 26, y + 11, Color(220, 220, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(res.count .. " (" .. math.Round(self.BarAnims[i], 1) .. "%)", "DermaDefault", w - 26, y + 11, Color(120, 130, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
    
    surface.SetDrawColor(40, 40, 70)
    surface.DrawOutlinedRect(0, 0, w, h, 1)
end

vgui.Register("ZVote_Result", RESULT, "DFrame")

-- ==================== КЛИЕНТСКИЙ МЕНЕДЖЕР ====================

ZVote = ZVote or {}

function ZVote:OpenVoter(question, options, duration)
    if IsValid(self.VoterPanel) then self.VoterPanel:Remove() end
    
    self.VoterPanel = vgui.Create("ZVote_Voter")
    self.VoterPanel:SetVoteData(question, options, duration)
    
    if IsValid(self.MiniPanel) then self.MiniPanel:Remove() end
    if IsValid(self.ResultPanel) then self.ResultPanel:Remove() end
end

function ZVote:ShowMiniPanel()
    if not self:IsActive() then return end
    if IsValid(self.MiniPanel) then return end
    if IsValid(self.VoterPanel) then return end
    
    self.MiniPanel = vgui.Create("ZVote_MiniPanel")
    self.MiniPanel:SetData(self.ActiveQuestion, self.ActiveOptions)
    self.MiniPanel:UpdateResults(self.LastResults or {}, self.LastTotal or 0)
end

function ZVote:OpenVoterFromMini()
    if not self:IsActive() then return end
    self:OpenVoter(self.ActiveQuestion, self.ActiveOptions, self.ActiveEndTime - CurTime())
end

function ZVote:UpdateResults(results, total)
    self.LastResults = results
    self.LastTotal = total
    
    if IsValid(self.VoterPanel) then
        self.VoterPanel:UpdateResults(results, total)
    end
    if IsValid(self.MiniPanel) then
        self.MiniPanel:UpdateResults(results, total)
        self.MiniPanel.Pulse = 1
    end
end

function ZVote:EndVote(question, results, winnerIndex)
    -- СОХРАНЯЕМ опции ПЕРЕД очисткой
    local opts = self.ActiveOptions
    
    self.ActiveQuestion = nil
    self.ActiveOptions = nil
    self.ActiveEndTime = nil
    
    if IsValid(self.VoterPanel) then self.VoterPanel:Remove() end
    if IsValid(self.MiniPanel) then self.MiniPanel:Remove() end
    
    -- Показываем итоговое окно
    if opts then
        self.ResultPanel = vgui.Create("ZVote_Result")
        self.ResultPanel:SetData(question, results, winnerIndex, opts)
    end
    
    -- Уведомление
    local winnerName = opts and opts[winnerIndex] or "Ничья"
    chat.AddText(
        Color(66, 75, 245), "[Голосование] ",
        Color(220, 220, 220), "Завершено! ",
        Color(120, 130, 200), "Победитель: ",
        Color(66, 75, 245), winnerName
    )
    
    surface.PlaySound("buttons/blip1.wav")
end

function ZVote:IsActive()
    return self.ActiveEndTime and CurTime() < self.ActiveEndTime
end

net.Receive("ZVote_OpenVoter", function()
    local question = net.ReadString()
    local options = net.ReadTable()
    local duration = net.ReadFloat()
    
    ZVote.ActiveQuestion = question
    ZVote.ActiveOptions = options
    ZVote.ActiveEndTime = CurTime() + duration
    
    ZVote:OpenVoter(question, options, duration)
    surface.PlaySound("ui/buttonclick.wav")
end)

net.Receive("ZVote_UpdateResults", function()
    local results = net.ReadTable()
    local total = net.ReadInt(16)
    ZVote:UpdateResults(results, total)
end)

net.Receive("ZVote_CloseVoter", function()
    local question = net.ReadString()
    local results = net.ReadTable()
    local winner = net.ReadInt(8)
    
    ZVote:EndVote(question, results, winner)
end)

net.Receive("ZVote_SendMiniPanel", function()
    local show = net.ReadBool()
    if show then
        ZVote:ShowMiniPanel()
    end
end)

hook.Add("InitPostEntity", "ZVote_RequestState", function()
    timer.Simple(2, function()
        net.Start("ZVote_RequestState")
        net.SendToServer()
    end)
end)
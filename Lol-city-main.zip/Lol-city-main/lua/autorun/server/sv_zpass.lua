﻿if SERVER then
    util.AddNetworkString("ZPass_RequestStatus")
    util.AddNetworkString("ZPass_SendStatus")
    util.AddNetworkString("ZPass_ApplySkin")
    util.AddNetworkString("ZPass_Admin_OpenMenu")
    util.AddNetworkString("ZPass_Admin_SendMenuData")
    util.AddNetworkString("ZPass_Admin_ManagePass")
    util.AddNetworkString("ZPass_Admin_ToggleSkin")
end

ZPass = ZPass or {}
ZPass.Data = ZPass.Data or {}
ZPass.Config = ZPass.Config or { AllowedSkins = {} }
ZPass.PlayerSkins = ZPass.PlayerSkins or {}
ZPass._cooldowns = ZPass._cooldowns or {}
ZPass._saveScheduled = ZPass._saveScheduled or false

file.CreateDir("zpass")

local COOLDOWN_STATUS = 1
local COOLDOWN_APPLY = 0.5
local COOLDOWN_ADMIN = 1
local MAX_TARGET_LEN = 64
local MAX_BODYGROUPS = 32
local MAX_BODYGROUP_VALUE = 255

local function CheckCooldown(ply, key, duration)
    if not IsValid(ply) then return false end
    local sid = ply:SteamID()
    ZPass._cooldowns[sid] = ZPass._cooldowns[sid] or {}
    local now = CurTime()
    if ZPass._cooldowns[sid][key] and now - ZPass._cooldowns[sid][key] < duration then
        return false
    end
    ZPass._cooldowns[sid][key] = now
    return true
end

function ZPass:SaveData()
    file.Write("zpass/players.json", util.TableToJSON(self.Data, true))
end

function ZPass:ScheduleSave()
    if self._saveScheduled then return end
    self._saveScheduled = true
    timer.Simple(2, function()
        ZPass._saveScheduled = false
        ZPass:SaveData()
    end)
end

function ZPass:LoadData()
    if file.Exists("zpass/players.json", "DATA") then
        local content = file.Read("zpass/players.json", "DATA")
        self.Data = util.JSONToTable(content) or {}
    end
end

function ZPass:SaveConfig()
    file.Write("zpass/config.json", util.TableToJSON(self.Config, true))
end

function ZPass:ScheduleConfigSave()
    if self._configSaveScheduled then return end
    self._configSaveScheduled = true
    timer.Simple(2, function()
        ZPass._configSaveScheduled = false
        ZPass:SaveConfig()
    end)
end

function ZPass:LoadConfig()
    if file.Exists("zpass/config.json", "DATA") then
        local content = file.Read("zpass/config.json", "DATA")
        self.Config = util.JSONToTable(content) or { AllowedSkins = {} }
    end
end

ZPass:LoadData()
ZPass:LoadConfig()

local function FindPlayer(info)
    if not info or info == "" then return nil end
    if #info > MAX_TARGET_LEN then return nil end
    for _, ply in ipairs(player.GetAll()) do
        if ply:SteamID() == info then
            return ply
        end
    end
    for _, ply in ipairs(player.GetAll()) do
        if string.find(ply:Nick():lower(), info:lower(), 1, true) then
            return ply
        end
    end
    return nil
end

function ZPass:IsAdmin(ply)
    if not IsValid(ply) then return false end
    return ply:IsAdmin() or ply:IsSuperAdmin() or ply:IsUserGroup("admin") or ply:IsUserGroup("superadmin")
end

function ZPass:HasPass(ply)
    if not IsValid(ply) then return false end
    if self:IsAdmin(ply) then return true end
    local steamid = ply:SteamID()
    return self.Data[steamid] ~= nil
end

function ZPass:HasPlus(ply)
    if not IsValid(ply) then return false end
    if self:IsAdmin(ply) then return true end
    local steamid = ply:SteamID()
    return self.Data[steamid] and self.Data[steamid].type == "Z-PASS+"
end

function ZPass:SyncType(ply)
    if not IsValid(ply) then return end
    local data = self.Data[ply:SteamID()]
    if data and data.type then
        ply:SetNWString("ZPassType", data.type)
    else
        ply:SetNWString("ZPassType", "")
    end
end

function ZPass:AddPass(targetInfo, passType, issuer)
    local target = FindPlayer(targetInfo)
    local steamid = target and target:SteamID() or targetInfo
    local nick = target and target:Nick() or targetInfo

    local issuerNick = "CONSOLE"
    local issuerSteamID = "SERVER"

    if IsValid(issuer) then
        issuerNick = issuer:Nick()
        issuerSteamID = issuer:SteamID()
    end

    self.Data[steamid] = {
        nick = nick,
        steamid = steamid,
        type = passType,
        issuer_nick = issuerNick,
        issuer_steamid = issuerSteamID
    }

    self:SaveData()

    if IsValid(target) then
        self:SyncType(target)
        target:ChatPrint("[Z-Pass] Вам выдан " .. passType .. "!")
        self:SendStatus(target)
    end

    return nick
end

function ZPass:RemovePass(targetInfo)
    local target = FindPlayer(targetInfo)
    local steamid = target and target:SteamID() or targetInfo
    local nick = target and target:Nick() or targetInfo

    if self.Data[steamid] then
        self.Data[steamid] = nil
        self:SaveData()
    end

    if IsValid(target) then
        self.PlayerSkins[target:SteamID()] = nil
        self:SyncType(target)
        target:ChatPrint("[Z-Pass] Ваш Z-PASS был удален!")
        self:SendStatus(target)
    end

    return nick
end

function ZPass:SendStatus(ply)
    if not IsValid(ply) then return end
    
    local isAdmin = ply:IsAdmin() or ply:IsUserGroup("admin")
    local isSuperAdmin = ply:IsSuperAdmin() or ply:IsUserGroup("superadmin")
    
    net.Start("ZPass_SendStatus")
        net.WriteBool(self:HasPass(ply))
        net.WriteBool(self:HasPlus(ply))
        net.WriteBool(isAdmin)
        net.WriteBool(isSuperAdmin)
        net.WriteTable(self.Config.AllowedSkins or {})
    net.Send(ply)
end

function ZPass:ValidateBodygroups(bodygroups)
    if not istable(bodygroups) then return {} end
    local clean = {}
    local count = 0
    for id, val in pairs(bodygroups) do
        if type(id) ~= "number" or type(val) ~= "number" then continue end
        if id < 0 or id > MAX_BODYGROUPS then continue end
        if val < 0 or val > MAX_BODYGROUP_VALUE then continue end
        count = count + 1
        if count > MAX_BODYGROUPS then break end
        clean[id] = math.floor(val)
    end
    return clean
end

function ZPass:ApplySkin(ply, model, skinVal, bodygroups)
    if not IsValid(ply) then return false end
    
    if type(model) ~= "string" or #model > 256 then return false end
    if type(skinVal) ~= "number" then skinVal = 0 end
    skinVal = math.Clamp(math.floor(skinVal), 0, MAX_BODYGROUP_VALUE)

    bodygroups = self:ValidateBodygroups(bodygroups)

    if not self:HasPass(ply) then
        ply:ChatPrint("[Z-Pass] У вас нет Z-PASS!")
        return false
    end

    if not self:IsAdmin(ply) and not self.Config.AllowedSkins[model] then
        ply:ChatPrint("[Z-Pass] Данный скин недоступен для обычных игроков!")
        return false
    end
    
    if not util.IsValidModel(model) then
        ply:ChatPrint("[Z-Pass] Указанная модель недоступна!")
        return false
    end
    
    self.PlayerSkins[ply:SteamID()] = {
        model = model,
        skinVal = skinVal,
        bodygroups = bodygroups
    }
    
    ply:SetSubMaterial()
    ply:SetMaterial("")
    ply:SetModel(model)
    ply:SetSkin(skinVal)
    
    for _, bg in ipairs(ply:GetBodyGroups() or {}) do
        ply:SetBodygroup(bg.id, 0)
    end
    
    for id, val in pairs(bodygroups) do
        ply:SetBodygroup(id, val)
    end
    
    ply:SetupBones()
    ply:ChatPrint("[Z-Pass] Скин и бодигруппы успешно применены!")
    return true
end

net.Receive("ZPass_RequestStatus", function(len, ply)
    if not IsValid(ply) then return end
    if not CheckCooldown(ply, "status", COOLDOWN_STATUS) then return end
    ZPass:SendStatus(ply)
end)

net.Receive("ZPass_ApplySkin", function(len, ply)
    if not IsValid(ply) then return end
    if not CheckCooldown(ply, "apply", COOLDOWN_APPLY) then return end
    local model = net.ReadString()
    local skinVal = net.ReadUInt(8)
    local bodygroups = net.ReadTable()
    ZPass:ApplySkin(ply, model, skinVal, bodygroups)
end)

net.Receive("ZPass_Admin_OpenMenu", function(len, ply)
    if not IsValid(ply) then return end
    if not ZPass:IsAdmin(ply) then return end
    if not CheckCooldown(ply, "admin", COOLDOWN_ADMIN) then return end
    
    net.Start("ZPass_Admin_SendMenuData")
        net.WriteTable(ZPass.Config.AllowedSkins or {})
        net.WriteTable(ZPass.Data or {})
    net.Send(ply)
end)

net.Receive("ZPass_Admin_ToggleSkin", function(len, ply)
    if not IsValid(ply) then return end
    if not ZPass:IsAdmin(ply) then return end
    if not CheckCooldown(ply, "toggle", COOLDOWN_ADMIN) then return end
    
    local model = net.ReadString()
    local state = net.ReadBool()

    if type(model) ~= "string" or #model > 256 then return end
    
    if state then
        ZPass.Config.AllowedSkins[model] = true
    else
        ZPass.Config.AllowedSkins[model] = nil
    end
    
    ZPass:ScheduleConfigSave()
    
    for _, p in ipairs(player.GetAll()) do
        ZPass:SendStatus(p)
    end
end)

net.Receive("ZPass_Admin_ManagePass", function(len, ply)
    if not IsValid(ply) then return end
    if not ZPass:IsAdmin(ply) then return end
    if not CheckCooldown(ply, "manage", COOLDOWN_ADMIN) then return end
    
    local targetInfo = net.ReadString()
    local action = net.ReadString()

    if type(targetInfo) ~= "string" or #targetInfo > MAX_TARGET_LEN then return end
    if type(action) ~= "string" or #action > 16 then return end
    
    if action == "add" then
        ZPass:AddPass(targetInfo, "Z-PASS", ply)
    elseif action == "addplus" then
        ZPass:AddPass(targetInfo, "Z-PASS+", ply)
    elseif action == "remove" then
        ZPass:RemovePass(targetInfo)
    end
end)

hook.Add("PlayerInitialSpawn", "ZPass_SyncTypeOnJoin", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then
            ZPass:SyncType(ply)
        end
    end)
end)

hook.Add("PlayerSpawn", "ZPass_RestoreSkinOnSpawn", function(ply)
    if ply:GetInfoNum("zpass_auto_apply", 1) == 0 then return end

    timer.Simple(0.1, function()
        if not IsValid(ply) then return end
        local skinData = ZPass.PlayerSkins[ply:SteamID()]
        if skinData and ZPass:HasPass(ply) then
            ply:SetSubMaterial()
            ply:SetMaterial("")
            ply:SetModel(skinData.model)
            if skinData.skinVal then ply:SetSkin(skinData.skinVal) end
            if skinData.bodygroups then
                for id, val in pairs(skinData.bodygroups) do
                    ply:SetBodygroup(id, val)
                end
            end
        end
    end)
end)

hook.Add("PlayerDisconnected", "ZPass_CleanCooldowns", function(ply)
    local sid = ply:SteamID()
    if ZPass._cooldowns[sid] then
        ZPass._cooldowns[sid] = nil
    end
end)

print("[Z-Pass] Server script fully loaded!")
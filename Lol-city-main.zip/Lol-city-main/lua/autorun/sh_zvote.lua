﻿if SERVER then
    util.AddNetworkString("ZVote_OpenCreator")
    util.AddNetworkString("ZVote_OpenVoter")
    util.AddNetworkString("ZVote_UpdateResults")
    util.AddNetworkString("ZVote_CastVote")
    util.AddNetworkString("ZVote_CreateVote")
    util.AddNetworkString("ZVote_CloseVoter")
    util.AddNetworkString("ZVote_RequestState")
    util.AddNetworkString("ZVote_SendMiniPanel")
end

ZVote = ZVote or {}
ZVote.ActiveVote = nil
ZVote.Votes = {}
ZVote._cooldowns = ZVote._cooldowns or {}

local COOLDOWN_CREATE = 5
local COOLDOWN_CAST = 0.5
local COOLDOWN_REQUEST = 2
local MAX_QUESTION_LEN = 100
local MIN_QUESTION_LEN = 3
local MAX_OPTION_LEN = 50
local MAX_OPTIONS = 5
local MIN_OPTIONS = 2

local function CheckCooldown(ply, key, duration)
    if not IsValid(ply) then return false end
    local sid = ply:SteamID()
    ZVote._cooldowns[sid] = ZVote._cooldowns[sid] or {}
    local now = CurTime()
    if ZVote._cooldowns[sid][key] and now - ZVote._cooldowns[sid][key] < duration then
        return false
    end
    ZVote._cooldowns[sid][key] = now
    return true
end

local function ValidateOptions(options)
    if not istable(options) then return nil end
    if #options < MIN_OPTIONS or #options > MAX_OPTIONS then return nil end
    local clean = {}
    for i = 1, #options do
        local opt = options[i]
        if type(opt) ~= "string" then return nil end
        if #opt < 1 or #opt > MAX_OPTION_LEN then return nil end
        clean[i] = opt
    end
    return clean
end

function ZVote:CanCreateVote(ply)
    if not IsValid(ply) then return false end
    if ply:IsSuperAdmin() then return true end
    if ply:IsAdmin() then return true end
    local ok, userGroup = pcall(function() return ply:GetUserGroup() end)
    if ok and userGroup then
        local group = string.lower(userGroup)
        if group == "superadmin" or group == "admin" then return true end
    end
    if ULib and ULib.ucl and ULib.ucl.query then
        local ok2, hasPerm = pcall(function() return ULib.ucl.query(ply, "ulx vote") end)
        if ok2 and hasPerm then return true end
    end
    if CAMI and CAMI.PlayerHasAccess then
        local ok3, hasAccess = pcall(function() return CAMI.PlayerHasAccess(ply, "ZVote_Create") end)
        if ok3 and hasAccess then return true end
    end
    return false
end

function ZVote:IsActive()
    return self.ActiveVote ~= nil and CurTime() < self.ActiveVote.EndTime
end

function ZVote:GetResults()
    if not self.ActiveVote then return {} end
    local total = table.Count(self.Votes)
    local results = {}
    for i = 1, #self.ActiveVote.Options do
        results[i] = { count = 0, percent = 0 }
    end
    for _, choice in pairs(self.Votes) do
        if results[choice] then
            results[choice].count = results[choice].count + 1
        end
    end
    for i = 1, #results do
        results[i].percent = total > 0 and math.Round(results[i].count / total * 100, 1) or 0
    end
    return results, total
end

function ZVote:BroadcastResults()
    if not self.ActiveVote then return end
    local results, total = self:GetResults()
    net.Start("ZVote_UpdateResults")
    net.WriteTable(results)
    net.WriteInt(total, 16)
    net.Broadcast()
end

function ZVote:SendResultsTo(ply)
    if not IsValid(ply) then return end
    if not self.ActiveVote then return end
    local results, total = self:GetResults()
    net.Start("ZVote_UpdateResults")
    net.WriteTable(results)
    net.WriteInt(total, 16)
    net.Send(ply)
end

function ZVote:StartVote(question, options, duration, creator)
    if self:IsActive() then
        if IsValid(creator) then 
            creator:ChatPrint("[ZVote] Голосование уже идёт!") 
        end
        return false
    end
    self.ActiveVote = {
        Question = question,
        Options = options,
        EndTime = CurTime() + duration,
        Creator = creator and creator:SteamID() or "console"
    }
    self.Votes = {}
    
    net.Start("ZVote_OpenVoter")
    net.WriteString(question)
    net.WriteTable(options)
    net.WriteFloat(duration)
    net.Broadcast()
    
    local creatorName = IsValid(creator) and creator:Nick() or "Консоль"
    for _, ply in ipairs(player.GetAll()) do
        ply:ChatPrint("[ZVote] Новое голосование от " .. creatorName .. "!")
        ply:ChatPrint("[ZVote] " .. question)
    end
    
    timer.Create("ZVote_EndTimer", duration, 1, function() self:EndVote() end)
    timer.Create("ZVote_Updater", 1, 0, function()
        if not self:IsActive() then timer.Remove("ZVote_Updater") return end
        self:BroadcastResults()
    end)
    return true
end

function ZVote:EndVote()
    if not self.ActiveVote then return end
    timer.Remove("ZVote_EndTimer")
    timer.Remove("ZVote_Updater")
    
    local results, total = self:GetResults()
    local winnerIndex, winnerCount = 1, 0
    for i, res in ipairs(results) do
        if res.count > winnerCount then
            winnerIndex = i
            winnerCount = res.count
        end
    end
    
    net.Start("ZVote_CloseVoter")
    net.WriteString(self.ActiveVote.Question)
    net.WriteTable(results)
    net.WriteInt(winnerIndex, 8)
    net.Broadcast()
    
    local winnerName = self.ActiveVote.Options[winnerIndex] or "Ничья"
    local msg = "[ZVote] Голосование завершено! Победитель: " .. winnerName .. " (" .. winnerCount .. " голосов)"
    for _, ply in ipairs(player.GetAll()) do 
        ply:ChatPrint(msg) 
    end
    
    self.ActiveVote = nil
    self.Votes = {}
end

function ZVote:PlayerVoted(ply, option)
    if not IsValid(ply) then return end
    if not self:IsActive() then return end
    if type(option) ~= "number" then return end
    if not self.ActiveVote.Options[option] then return end
    if self.Votes[ply:SteamID()] then
        ply:ChatPrint("[ZVote] Вы уже проголосовали!")
        return
    end
    self.Votes[ply:SteamID()] = option
    self:BroadcastResults()
    
    ply:ChatPrint("[ZVote] Вы проголосовали за: " .. self.ActiveVote.Options[option])
    
    net.Start("ZVote_SendMiniPanel")
    net.WriteBool(true)
    net.Send(ply)
end

function ZVote:HandleChatCommand(ply, text)
    local cmd = string.lower(string.Trim(text))
    if cmd ~= "!zvote" and cmd ~= "/zvote" then return end

    if not ZVote:CanCreateVote(ply) then
        ply:ChatPrint("[ZVote] У вас нет прав для создания голосования!")
        return ""
    end

    if ZVote:IsActive() then
        ply:ChatPrint("[ZVote] Сейчас идёт другое голосование!")
        return ""
    end

    if not CheckCooldown(ply, "create", COOLDOWN_CREATE) then
        ply:ChatPrint("[ZVote] Подождите перед созданием нового голосования!")
        return ""
    end

    net.Start("ZVote_OpenCreator")
    net.Send(ply)
    return ""
end

if SERVER then
    hook.Add("PlayerSay", "ZVote_ChatCommand", function(ply, text)
        return ZVote:HandleChatCommand(ply, text)
    end)

    hook.Add("HG_PlayerSay", "ZVote_ZChatIntegration", function(ply, txtTbl, text)
        local cmd = string.lower(string.Trim(text))
        if cmd ~= "!zvote" and cmd ~= "/zvote" then return end

        if not ZVote:CanCreateVote(ply) then
            ply:ChatPrint("[ZVote] У вас нет прав для создания голосования!")
            txtTbl[1] = ""
            return
        end

        if ZVote:IsActive() then
            ply:ChatPrint("[ZVote] Сейчас идёт другое голосование!")
            txtTbl[1] = ""
            return
        end

        if not CheckCooldown(ply, "create", COOLDOWN_CREATE) then
            ply:ChatPrint("[ZVote] Подождите перед созданием нового голосования!")
            txtTbl[1] = ""
            return
        end

        net.Start("ZVote_OpenCreator")
        net.Send(ply)
        txtTbl[1] = ""
    end)

    timer.Simple(1, function()
        COMMANDS = COMMANDS or {}
        COMMANDS.zvote = {function(ply, args)
            if not ZVote:CanCreateVote(ply) then
                ply:ChatPrint("[ZVote] У вас нет прав для создания голосования!")
                return
            end
            if ZVote:IsActive() then
                ply:ChatPrint("[ZVote] Сейчас идёт другое голосование!")
                return
            end
            if not CheckCooldown(ply, "create", COOLDOWN_CREATE) then
                ply:ChatPrint("[ZVote] Подождите перед созданием нового голосования!")
                return
            end
            net.Start("ZVote_OpenCreator")
            net.Send(ply)
        end, 0}
        print("[ZVote] Registered COMMANDS.zvote")
    end)

    concommand.Add("zvote_create", function(ply, cmd, args)
        if not IsValid(ply) then
            print("[ZVote] Используйте !zvote в чате")
            return
        end
        if not ZVote:CanCreateVote(ply) then
            ply:ChatPrint("[ZVote] У вас нет прав!")
            return
        end
        if ZVote:IsActive() then
            ply:ChatPrint("[ZVote] Голосование уже идёт!")
            return
        end
        if not CheckCooldown(ply, "create", COOLDOWN_CREATE) then
            ply:ChatPrint("[ZVote] Подождите перед созданием нового голосования!")
            return
        end
        net.Start("ZVote_OpenCreator")
        net.Send(ply)
    end)

    print("[ZVote] Loaded! Chat: !zvote / /zvote | Console: zvote_create")
end

if SERVER then
    net.Receive("ZVote_CreateVote", function(len, ply)
        if not IsValid(ply) then return end
        if not ZVote:CanCreateVote(ply) then
            ply:ChatPrint("[ZVote] У вас нет прав для создания голосования!")
            return
        end
        if ZVote:IsActive() then return end
        if not CheckCooldown(ply, "create", COOLDOWN_CREATE) then return end
        
        local question = net.ReadString()
        local options = net.ReadTable()
        local duration = net.ReadInt(16)

        if type(question) ~= "string" then return end
        if #question < MIN_QUESTION_LEN or #question > MAX_QUESTION_LEN then 
            ply:ChatPrint("[ZVote] Вопрос должен быть от " .. MIN_QUESTION_LEN .. " до " .. MAX_QUESTION_LEN .. " символов!")
            return 
        end

        options = ValidateOptions(options)
        if not options then
            ply:ChatPrint("[ZVote] Некорректные варианты ответа!")
            return
        end

        if type(duration) ~= "number" then duration = 60 end
        if duration < 10 or duration > 300 then duration = 60 end
        
        ZVote:StartVote(question, options, duration, ply)
    end)

    net.Receive("ZVote_CastVote", function(len, ply)
        if not IsValid(ply) then return end
        if not CheckCooldown(ply, "cast", COOLDOWN_CAST) then return end
        local option = net.ReadInt(8)
        ZVote:PlayerVoted(ply, option)
    end)

    net.Receive("ZVote_RequestState", function(len, ply)
        if not IsValid(ply) then return end
        if not CheckCooldown(ply, "request", COOLDOWN_REQUEST) then return end
        if ZVote:IsActive() then
            net.Start("ZVote_OpenVoter")
            net.WriteString(ZVote.ActiveVote.Question)
            net.WriteTable(ZVote.ActiveVote.Options)
            net.WriteFloat(ZVote.ActiveVote.EndTime - CurTime())
            net.Send(ply)
            ZVote:SendResultsTo(ply)
        end
    end)

    hook.Add("PlayerDisconnected", "ZVote_CleanCooldowns", function(ply)
        local sid = ply:SteamID()
        if ZVote._cooldowns[sid] then
            ZVote._cooldowns[sid] = nil
        end
    end)
end
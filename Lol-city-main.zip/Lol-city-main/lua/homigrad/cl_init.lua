-- =====================================================
-- СИСТЕМА СУИЦИДА С ТЕКСТАМИ НА ЭКРАНЕ
-- =====================================================

local suicideTexts = {}
local suicideEffectActive = false
local isSuiciding = false

-- Фразы для отображения
local phrases = {
    "...", "why", "no", "stop", "please",
    "не надо", "зачем", "стой", "...", "нет",
    "help", "..." , "я устал", "всё равно",
    "за что", "почему", "хватит", "нет..."
}

-- Получаем синхронизацию с сервером
net.Receive("suicide_sync", function()
    isSuiciding = net.ReadBool()
    if isSuiciding then
        StartSuicideEffect()
    else
        StopSuicideEffect()
    end
end)

-- Функция создания одного текста
local function CreateSuicideText()
    if not isSuiciding then return end
    
    -- Случайная позиция (0-100% экрана)
    local x = math.random(5, 95) / 100
    local y = math.random(5, 95) / 100
    
    -- Случайная фраза
    local text = phrases[math.random(#phrases)]
    
    -- Создаём label
    local label = vgui.Create("DLabel")
    label:SetText(text)
    label:SetFont("DermaLarge")
    
    -- Случайный цвет (красные оттенки)
    local r = math.random(200, 255)
    local g = math.random(0, 80)
    local b = math.random(0, 80)
    label:SetTextColor(Color(r, g, b, 255))
    
    label:SetPos(ScrW() * x - 50, ScrH() * y - 20)
    label:SizeToContents()
    label:SetAlpha(0)
    
    table.insert(suicideTexts, label)
    
    -- Плавное появление
    label:AlphaTo(255, 0.4, 0)
    
    -- Через случайное время плавно исчезаем
    local lifeTime = math.random(10, 40) / 10
    timer.Simple(lifeTime, function()
        if IsValid(label) then
            label:AlphaTo(0, 0.5, 0, function()
                if IsValid(label) then
                    label:Remove()
                end
            end)
        end
    end)
end

-- Запуск эффекта
function StartSuicideEffect()
    if suicideEffectActive then return end
    suicideEffectActive = true
    isSuiciding = true
    
    -- Очищаем старые тексты
    for _, v in ipairs(suicideTexts) do
        if IsValid(v) then v:Remove() end
    end
    suicideTexts = {}
    
    -- Создаём таймер для появления текстов
    local function SpawnLoop()
        if not isSuiciding then return end
        
        CreateSuicideText()
        
        -- Иногда создаём 2-3 текста одновременно
        local extra = math.random(1, 10)
        if extra <= 3 then
            CreateSuicideText()
            if extra == 1 then
                CreateSuicideText()
                CreateSuicideText()
            end
        end
        
        timer.Simple(math.random(2, 8) / 10, SpawnLoop)
    end
    
    SpawnLoop()
end

-- Остановка эффекта
function StopSuicideEffect()
    isSuiciding = false
    suicideEffectActive = false
    
    for _, v in ipairs(suicideTexts) do
        if IsValid(v) then
            v:AlphaTo(0, 0.3, 0, function()
                if IsValid(v) then v:Remove() end
            end)
        end
    end
    
    timer.Simple(0.4, function()
        suicideTexts = {}
    end)
end

-- Проверка состояния при спавне
hook.Add("Think", "SuicideTextChecker", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    
    if ply:Alive() and isSuiciding then
        StopSuicideEffect()
    end
end)

-- Очистка при смене карты
hook.Add("OnReloaded", "SuicideTextCleanup", function()
    StopSuicideEffect()
end)

-- Клиентская команда для тестирования
concommand.Add("suicide_local", function()
    isSuiciding = not isSuiciding
    if isSuiciding then
        StartSuicideEffect()
        print("Суицид (локально) активирован")
    else
        StopSuicideEffect()
        print("Суицид (локально) деактивирован")
    end
end)
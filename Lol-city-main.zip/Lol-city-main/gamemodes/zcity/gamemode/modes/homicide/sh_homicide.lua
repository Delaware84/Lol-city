local MODE = MODE
MODE.name = "hmcd"
MODE.PrintName = "Homicide"

--\\
MODE.TraitorExpectedAmtBits = 13
--//

--\\Sub Roles
MODE.ConVarName_SubRole_Traitor_SOE = "hmcd_subrole_traitor_soe"
MODE.ConVarName_SubRole_Traitor = "hmcd_subrole_traitor"

if(CLIENT)then
	MODE.ConVar_SubRole_Traitor_SOE = CreateClientConVar(MODE.ConVarName_SubRole_Traitor_SOE, "traitor_default_soe", true, true, "Select traitor role in State of Emergency homicide mode")
	MODE.ConVar_SubRole_Traitor = CreateClientConVar(MODE.ConVarName_SubRole_Traitor, "traitor_default", true, true, "Select murder role in Standard homicide modes")
end

--; TODO
--; Инженер - шахид бомба + иеды

MODE.SubRoles = {
	--=\\Traitor
	--==\\
	--; https://youtu.be/zP7ux8WsYYI?si=S-Uw2EAehGR5WD3D
	["traitor_default"] = {
		Name = "дефоко",
		Description = [[по умолчанию.
вы готовились к этому моменту долгое время.
вы оснащены различными оружиями, ядами и взрывчатыми веществами, гранатами и вашим любимым тяжелым ножом и бесшумным пистолетом с дополнительным магазином, чтобы помочь вам убивать.]],
		Objective = "вы оснащены предметами, ядами, взрывчатыми веществами и оружием, спрятанным в ваших карманах. Убейте всех здесь.",
		SpawnFunction = function(ply)
			if not IsValid(ply) then return end
			local wep = ply:Give("weapon_p22")
			if not IsValid(wep) then return end
			
			timer.Simple(1, function()
				if not IsValid(wep) then return end
				wep:ApplyAmmoChanges(2)
			end)
			
			hg.AddAttachmentForce(ply, wep, "supressor4")
			ply:Give("weapon_buck200knife")	
			ply:Give("weapon_hg_rgd_tpik")
			ply:Give("weapon_adrenaline")
			ply:Give("weapon_hg_shuriken")
			ply:Give("weapon_hg_smokenade_tpik")
			ply:Give("weapon_traitor_ied")
			ply:Give("weapon_traitor_poison1")
			ply:Give("weapon_traitor_suit")
			ply:Give("weapon_hg_jam")
			-- ply:Give("weapon_traitor_poison2")
			-- ply:Give("weapon_traitor_poison3")
			
			ply.organism.stamina.max = 220
			local inv = ply:GetNetVar("Inventory", {})
			inv["Weapons"]["hg_flashlight"] = true
			
			ply:SetNetVar("Inventory", inv)
		end,
	},
	["traitor_default_soe"] = {
		Name = "дефоко",
		Description = [[по умолчанию.
вы готовились к этому моменту долгое время.
вы оснащены различными оружиями, ядами и взрывчатыми веществами, гранатами и вашим любимым тяжелым ножом и бесшумным пистолетом с дополнительным магазином, чтобы помочь вам убивать.]],
		Objective = "You're geared up with items, poisons, explosives and weapons hidden in your pockets. Murder everyone here.",
		SpawnFunction = function(ply)
			if not IsValid(ply) then return end
			local p22 = ply:Give("weapon_p22")
			if not IsValid(p22) then return end
			ply:GiveAmmo(p22:GetMaxClip1() * 1, p22:GetPrimaryAmmoType(), true)
			
			hg.AddAttachmentForce(ply, p22, "supressor4")
			ply:Give("weapon_sogknife")	
			ply:Give("weapon_hg_rgd_tpik")
			-- ply:Give("weapon_walkie_talkie")
			ply:Give("weapon_adrenaline")
			ply:Give("weapon_hg_smokenade_tpik")
			ply:Give("weapon_traitor_ied")
			ply:Give("weapon_traitor_poison2")
			ply:Give("weapon_traitor_poison3")
			
			ply.organism.recoilmul = 1
			ply.organism.stamina.max = 220
			local inv = ply:GetNetVar("Inventory", {})
			inv["Weapons"]["hg_flashlight"] = true
			
			ply:SetNetVar("Inventory",inv)
		end,
	},
	--==//
	
	--==\\
	["traitor_infiltrator"] = {
		Name = "диверсант",
		Description = [[Может ломать шеи людям сзади.
может полностью маскироваться под других игроков, если они в рэгдолле.
не имеет оружия или инструментов, кроме ножа, эпипена и дымовой гранаты.
для тех, кто любит играть в шахматы.]],
		Objective = "вы эксперт в отвлечении. будьте осторожны и убивайте по одному",
		SpawnFunction = function(ply)
			ply:Give("weapon_sogknife")
			ply:Give("weapon_adrenaline")
			ply:Give("weapon_hg_smokenade_tpik")
			
			ply.organism.stamina.max = 220
			local inv = ply:GetNetVar("Inventory", {})
			inv["Weapons"]["hg_flashlight"] = true
			
			ply:SetNetVar("Inventory", inv)
		end,
	},
	["traitor_infiltrator_soe"] = {
		Name = "диверсант",
		Description = [[может ломать шеи людям сзади.
может полностью маскироваться под других игроков, если они в рэгдолле.
имеет дымовую гранату, рацию, нож, тазер с 2 дополнительными стреляющими головками и эпипен.
для тех, кто любит играть в шахматы.]],
		Objective = "вы эксперт в отвлечении. будьте осторожны и убивайте по одному",
		SpawnFunction = function(ply)
			local taser = ply:Give("weapon_taser")
			
			ply:GiveAmmo(taser:GetMaxClip1() * 2, taser:GetPrimaryAmmoType(), true)
			ply:Give("weapon_sogknife")
			-- ply:Give("weapon_hg_rgd_tpik")
			-- ply:Give("weapon_walkie_talkie")
			ply:Give("weapon_adrenaline")
			ply:Give("weapon_hg_smokenade_tpik")
			
			ply.organism.recoilmul = 1
			ply.organism.stamina.max = 220
			local inv = ply:GetNetVar("Inventory", {})
			inv["Weapons"]["hg_flashlight"] = true
			
			ply:SetNetVar("Inventory", inv)
		end,
	},
	--==//
	
	--==\\
	--; СДЕЛАТЬ ЕМУ ЛУТ ДРУГИХ ИГРОКОВ ДАЖЕ ПОКА У НИХ НЕТ ПУШКИ В РУКАХ
	--; Сделать ему вырубание по вагус нерву
	["traitor_assasin"] = {
		Name = "ассасин",
		Description = [[может быстро разоружать людей с любого угла.
разоружает быстрее сзади.
разоружает быстрее спереди, если жертва в рэгдолле.
опытен в стрельбе из оружия.
имеет дополнительную выносливость (+ 80 единиц по сравнению с другими предателями).
оснащен рацией.
для тех, кто любит играть в шахматы.]],
		Objective = "вы эксперт в стрельбе и разоружении. разоружайте стрелков и используйте их оружие против других",
		SpawnFunction = function(ply)
			-- ply:Give("weapon_sogknife")	
			-- ply:Give("weapon_adrenaline")
			-- ply:Give("weapon_hg_smokenade_tpik")
			-- ply:Give("weapon_hg_shuriken")
			
			ply.organism.recoilmul = 0.8
			ply.organism.stamina.max = 300
			--local inv = ply:GetNetVar("Inventory", {}) // WHY SOMEONE COMMENTED THIS
			--inv["Weapons"]["hg_flashlight"] = true
			
			--ply:SetNetVar("Inventory", inv) // BUT NOT THIS???
		end,
	},
	["traitor_assasin_soe"] = {
		Name = "ассасин",
		Description = [[может быстро разоружать людей с любого угла.
разоружает быстрее сзади.
разоружает быстрее спереди, если жертва в рэгдолле.
опытен в стрельбе из оружия.
имеет дополнительную выносливость (+ 80 единиц по сравнению с другими предателями).
оснащен рацией.
для тех, кто любит играть в шахматы.]],
		Objective = "вы эксперт в стрельбе и разоружении. разоружайте стрелков и используйте их оружие против других",
		SpawnFunction = function(ply)
			ply:Give("weapon_sogknife")	
			ply:Give("weapon_adrenaline")
			-- ply:Give("weapon_walkie_talkie")
			-- ply:Give("weapon_hg_smokenade_tpik")
			-- ply:Give("weapon_hg_shuriken")
			
			ply.organism.recoilmul = 0.4
			ply.organism.stamina.max = 300
			--local inv = ply:GetNetVar("Inventory", {}) // WHY SOMEONE COMMENTED THIS
			--inv["Weapons"]["hg_flashlight"] = true
			
			--ply:SetNetVar("Inventory", inv) // BUT NOT THIS???
		end,
	},
	--==//
	
	--==\\
	["traitor_chemist"] = {
		Name = "химик",
		Description = [[имеет несколько химических агентов, эпипен и нож.
устойчив к определенной степени ко всем упомянутым химическим агентам.
может обнаруживать присутствие и силу химических агентов в воздухе.]],
		Objective = "Вы химик, который решил использовать свои знания, чтобы навредить другим. Отравляйте все.",
		SpawnFunction = function(ply)
			ply:Give("weapon_sogknife")
			ply:Give("weapon_adrenaline")
			ply:Give("weapon_traitor_poison1")
			ply:Give("weapon_traitor_poison2")
			ply:Give("weapon_traitor_poison3")
			ply:Give("weapon_traitor_poison4")
			ply:Give("weapon_traitor_poison_consumable")
			
			ply.organism.stamina.max = 220
			local inv = ply:GetNetVar("Inventory", {})
			inv["Weapons"]["hg_flashlight"] = true
			
			ply:SetNetVar("Inventory", inv)
			CleanChemicalsOfPlayer(ply)
		end,
	},
	--==//
	-- ["traitor_demoman"] = {
		-- Name = "Demoman",
		-- Description = [[Has many explosives.
-- Can rig certain items with bombs
-- (Radio, certain consumables, etc.)]],
		-- Objective = "You're the ultimate chemist who decided to use knowledge to hurt others.",
		-- SpawnFunction = function(ply)
			-- ply:Give("weapon_sogknife")
			-- ply:Give("weapon_adrenaline")
			-- ply:Give("weapon_hg_rgd_tpik")
			-- ply:Give("weapon_hg_pipebomb_tpik")
			-- ply:Give("weapon_hg_smokenade_tpik")
			-- ply:Give("weapon_traitor_ied")
			-- ply:Give("weapon_walkie_talkie")
			
			-- ply.organism.stamina.max = 220
			-- local inv = ply:GetNetVar("Inventory", {})
			-- inv["Weapons"]["hg_flashlight"] = true
			
			-- ply:SetNetVar("Inventory", inv)
		-- end,
	-- },
	["traitor_zombie"] = {
		Name = "зомбе",
		Description = [[может заражать других игроков бесшумно.
зараженные игроки могут быть вылечены доктором.
если все игроки будут вылечены, зомби проиграет.
вместо смерти будет случайным образом перемещен в тело другого зараженного игрока.
не имеет оружия или каких-либо инструментов.
несмотря на то, что зомби, все еще сохраняет вид обычного человека.]],
		Objective = "вы зомби. Заражайте всех, чтобы победить. Избегайте доктора.",
		SpawnFunction = function(ply)
			-- ply:Give("weapon_sogknife")	
			-- ply:Give("weapon_adrenaline")
			
			-- ply.organism.stamina.max = 220
			-- local inv = ply:GetNetVar("Inventory", {})
			-- inv["Weapons"]["hg_flashlight"] = true
			
			-- ply:SetNetVar("Inventory", inv)
		end,
	},
	--=//
}
--//

--\\Professions
MODE.ProfessionsRoundTypes = {
	["standard"] = true,
	["soe"] = true,
}

MODE.Professions = {
	["doctor"] = {
		Name = "доктор",
		SpawnFunction = function(ply)	--; TODO MAKE IT WORK
			--; It's a bad practice to give professions any weapons or tools
		end,
	},
	["huntsman"] = {
		Name = "охотник",
		SpawnFunction = function(ply)
			--; It's a bad practice to give professions any weapons or tools
		end,
	},
	["engineer"] = {
		Name = "инженер",
		SpawnFunction = function(ply)
			--; It's a bad practice to give professions any weapons or tools
		end,
	},
	["cook"] = {
		Name = "повар",
		SpawnFunction = function(ply)
			--; It's a bad practice to give professions any weapons or tools
		end,
	},
	["builder"] = {
		Name = "строитель",
		SpawnFunction = function(ply)
			--; It's a bad practice to give professions any weapons or tools
		end,
	},
}
--//

--\\
--; Названия перменных чуть чуть конченные получились, нужно будет подумать как улучшить
--; ужас
MODE.FadeScreenTime = 1.5
MODE.DefaultRoundStartTime = 6
MODE.RoleChooseRoundStartTime = 10

MODE.RoleChooseRoundTypes = {
	["standard"] = {
		TraitorDefaultRole = "traitor_default",
		Traitor = {
			["traitor_default"] = true,
			["traitor_infiltrator"] = true,
			["traitor_chemist"] = true,
			["traitor_assasin"] = true,
			--; ОБЪЕДЕНИТЬ ХИМИКА И ДИВЕРСАНТА!!! наверное
			-- ["traitor_demoman"] = true,
		},
		Professions = {
			["доктор"] = {
				Chance = 1,
			},
			["охотник"] = {
				Chance = 1,
			},
			["инженер"] = {
				Chance = 1,
			},
			["повар"] = {
				Chance = 1,
			},
			["строитель"] = {
				Chance = 1,
			},
		},
	},
	["soe"] = {
		TraitorDefaultRole = "traitor_default_soe",
		Traitor = {
			["traitor_default_soe"] = true,
			["traitor_infiltrator_soe"] = true,
			-- ["traitor_chemist_soe"] = true,
			["traitor_assasin_soe"] = true,
			-- ["traitor_demoman_soe"] = true,
		},
		Professions = {
			["доктор"] = {
				Chance = 1,
			},
			["охотник"] = {
				Chance = 1,
			},
			["инженер"] = {
				Chance = 1,
			},
			["повар"] = {
				Chance = 1,
			},
		},
	},
}
--//

MODE.Roles = {}
MODE.Roles.soe = {
	traitor = {
		name = "предатель вы хитрец",
		color = Color(190,0,0)
	},

	gunner = {
		name = "невинный",
		color = Color(158,0,190)
	},

	innocent = {
		name = "невинный",
		color = Color(0,120,190)
	},
}

MODE.Roles.standard = {
	traitor = {
		objective = "вы готовились к этому долгое время. Убейте всех.",
		name = "предатель вы хитрец",
		color = Color(190,0,0)
	},

	gunner = {
		name = "невинный",
		color = Color(158,0,190)
	},

	innocent = {
		name = "невинный",
		color = Color(0,120,190)
	},
}

MODE.Roles.wildwest = {
	traitor = {
		objective = "вы готовились к этому долгое время. Убейте всех.",
		name = "предатель вы хитрец",
		color = Color(190,0,0)
	},

	gunner = {
		name = "невинный",
		color = Color(159,85,0)
	},

	innocent = {
		name = "невинный",
		color = Color(159,85,0)
	},
}

MODE.Roles.gunfreezone = {
	traitor = {
		name = "предатель вы хитрец",
		color = Color(190,0,0)
	},

	gunner = {
		name = "невинный",
		color = Color(0,120,190)
	},

	innocent = {
		name = "невинный",
		color = Color(0,120,190)
	},
}

MODE.Roles.supermario = {
	traitor = {
		objective = "вы злой Марио! Прыгайте вокруг и уничтожайте всех.",
		name = "злой Марио",
		color = Color(190,0,0)
	},

	gunner = {
		objective = "вы герой Марио! Используйте свои прыжковые способности, чтобы остановить предателя.",
		name = "герой Марио",
		color = Color(158,0,190)
	},

	innocent = {
		objective = "вы наблюдательный Марио, выживайте и избегайте ловушек предателя!",
		name = "невинный Марио",
		color = Color(0,120,190)
	},
}

function MODE.GetPlayerTraceToOther(ply, aim_vector, dist)
	local trace = hg.eyeTrace(ply, dist, nil, aim_vector)
	
	if(trace)then
		local aim_ent = trace.Entity
		local other_ply = nil
		
		if(IsValid(aim_ent))then
			if(aim_ent:IsPlayer())then
				other_ply = aim_ent
			elseif(aim_ent:IsRagdoll())then
				if(IsValid(aim_ent.ply))then
					other_ply = aim_ent.ply
				end
			end
		end
		
		return aim_ent, other_ply, trace
	else
		return nil
	end
end